function  read(){
   var a= document.querySelector("#id1").value;
    a.innerHTML=a;
   
    document.querySelector("#id1").value="";
    document.querySelector("#id2").value="";
  
}

